/**
 * TaskFlow – Automated Test Suite
 * Run with: node test/test_suite.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// Mock localStorage
class LocalStorageMock {
  constructor() { this.store = {}; }
  getItem(k) { return this.store[k] || null; }
  setItem(k, v) { this.store[k] = String(v); }
  removeItem(k) { delete this.store[k]; }
  clear() { this.store = {}; }
}
global.localStorage = new LocalStorageMock();

// Mock DOM element factory
function createMockElement(id = '', tagName = 'div') {
  return {
    id,
    tagName,
    value: '',
    textContent: '',
    innerHTML: '',
    className: '',
    style: {},
    classList: {
      _classes: new Set(),
      add(c) { this._classes.add(c); },
      remove(c) { this._classes.delete(c); },
      toggle(c, f) {
        if (f === undefined) this._classes.has(c) ? this._classes.delete(c) : this._classes.add(c);
        else f ? this._classes.add(c) : this._classes.delete(c);
      },
      contains(c) { return this._classes.has(c); }
    },
    attributes: {},
    setAttribute(k, v) { this.attributes[k] = String(v); },
    getAttribute(k) { return this.attributes[k]; },
    children: [],
    appendChild(c) { this.children.push(c); return c; },
    querySelector(sel) {
      const child = createMockElement('', 'span');
      this.children.push(child);
      return child;
    },
    closest(sel) { return this; },
    addEventListener() {},
    scrollIntoView() {},
    focus() {}
  };
}

// Mock document
global.document = {
  readyState: 'complete',
  getElementById(id) {
    if (!this._elements[id]) this._elements[id] = createMockElement(id);
    return this._elements[id];
  },
  querySelectorAll(sel) {
    if (sel === '.filter-btn') {
      return [
        { ...createMockElement('btn-all'), dataset: { filter: 'all' } },
        { ...createMockElement('btn-active'), dataset: { filter: 'active' } },
        { ...createMockElement('btn-completed'), dataset: { filter: 'completed' } }
      ];
    }
    return [];
  },
  createElement(tag) {
    const el = createMockElement('', tag);
    el.dataset = {};
    return el;
  },
  createDocumentFragment() {
    return { children: [], appendChild(c) { this.children.push(c); } };
  },
  addEventListener() {},
  _elements: {}
};
global.window = global;

// Load script.js
const scriptPath = path.resolve(__dirname, '../js/script.js');
const scriptCode = fs.readFileSync(scriptPath, 'utf8');
vm.runInThisContext(scriptCode);

console.log('\n========================================');
console.log('  TaskFlow Automated Test Suite Running  ');
console.log('========================================\n');

let passedTests = 0;
let totalTests = 0;

function assert(condition, testName) {
  totalTests++;
  if (condition) {
    console.log(`  ✔ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`  ❌ [FAIL] ${testName}`);
  }
}

// 1. Add Task
addTask('Unit Test: Task 1');
addTask('Unit Test: Task 2');
addTask('Unit Test: Task 3');
assert(state.tasks.length === 3, '1. Successfully added 3 tasks');

// 2. LocalStorage Persistence
const stored = JSON.parse(localStorage.getItem('taskflow_tasks'));
assert(stored && stored.length === 3, '2. Tasks properly persisted to localStorage');

// 3. Reject Empty Input
assert(validateInput('') === null && validateInput('   ') === null, '3. Empty and whitespace-only inputs rejected');

// 4. Toggle Task Completion
const testTask = state.tasks[0];
toggleTask(testTask.id);
assert(testTask.completed === true, '4. Task completion status toggled to completed');

// 5. Statistics Calculation
updateStatistics();
assert(
  elements.statTotal.textContent === 3 &&
  elements.statCompleted.textContent === 1 &&
  elements.statActive.textContent === 2,
  '5. Statistics counters (Total, Active, Completed) are accurate'
);

// 6. Edit Task
const editTarget = state.tasks[1];
editTask(editTarget.id);
assert(state.editingTaskId === editTarget.id, '6a. Edit mode initialized with target ID');
saveEditedTask(editTarget.id, 'Updated Task Text');
assert(editTarget.text === 'Updated Task Text' && state.editingTaskId === null, '6b. Task updated and edit mode cleared');

// 7. Filtering (All, Active, Completed)
filterTasks('active');
assert(getFilteredTasks().length === 2, '7a. Filter "active" returns only non-completed tasks');
filterTasks('completed');
assert(getFilteredTasks().length === 1, '7b. Filter "completed" returns only completed tasks');
filterTasks('all');
assert(getFilteredTasks().length === 3, '7c. Filter "all" returns all tasks');

// 8. Delete Individual Task
const deleteTargetId = state.tasks[2].id;
deleteTask(deleteTargetId);
if (typeof pendingModalAction === 'function') pendingModalAction();
assert(!state.tasks.some(t => t.id === deleteTargetId), '8. Individual task deleted via confirmation modal');

// 9. Clear Completed Tasks
clearCompletedTasks();
if (typeof pendingModalAction === 'function') pendingModalAction();
assert(state.tasks.every(t => !t.completed), '9. All completed tasks removed via bulk clear');

// 10. State Restoration on Refresh
const reloaded = loadTasks();
assert(reloaded.length === state.tasks.length, '10. Saved state restored cleanly from localStorage');

console.log(`\nResults: ${passedTests}/${totalTests} tests passed.\n`);

if (passedTests === totalTests) {
  console.log('🎉 ALL TESTS COMPLETED SUCCESSFULLY!\n');
  process.exit(0);
} else {
  console.error('⚠️ SOME TESTS FAILED.\n');
  process.exit(1);
}

