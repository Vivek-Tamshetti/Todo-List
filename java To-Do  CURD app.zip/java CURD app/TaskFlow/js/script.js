'use strict';

const STORAGE_KEY = 'taskflow_tasks';

let state = {
  tasks: [],            
  currentFilter: 'all', 
  editingTaskId: null   
};

const elements = {

  currentDate: document.getElementById('current-date'),

  statTotal: document.getElementById('stat-total'),
  statActive: document.getElementById('stat-active'),
  statCompleted: document.getElementById('stat-completed'),
  statPercent: document.getElementById('stat-percent'),
  progressBarFill: document.getElementById('progress-bar-fill'),
  progressBarContainer: document.getElementById('progress-bar-container'),

  taskForm: document.getElementById('task-form'),
  taskInput: document.getElementById('task-input'),
  charCount: document.getElementById('char-count'),
  submitBtn: document.getElementById('submit-btn'),
  submitBtnText: document.getElementById('submit-btn-text'),
  cancelBtn: document.getElementById('cancel-btn'),
  formError: document.getElementById('form-error'),

  filterButtons: document.querySelectorAll('.filter-btn'),
  filterAllCount: document.getElementById('filter-all-count'),
  filterActiveCount: document.getElementById('filter-active-count'),
  filterCompletedCount: document.getElementById('filter-completed-count'),
  remainingCount: document.getElementById('remaining-count'),
  clearCompletedBtn: document.getElementById('clear-completed-btn'),

  taskList: document.getElementById('task-list'),
  emptyState: document.getElementById('empty-state'),

  confirmModal: document.getElementById('confirm-modal'),
  modalTitle: document.getElementById('modal-title'),
  modalMessage: document.getElementById('modal-message'),
  modalConfirmBtn: document.getElementById('modal-confirm-btn'),
  modalCancelBtn: document.getElementById('modal-cancel-btn'),

  toastContainer: document.getElementById('toast-container')
};

let pendingModalAction = null;

function loadTasks() {
  try {
    const rawData = localStorage.getItem(STORAGE_KEY);
    if (!rawData) {
      return [];
    }
    const parsed = JSON.parse(rawData);

    if (Array.isArray(parsed)) {
      return parsed;
    }
    console.warn('[TaskFlow] Invalid data format in localStorage; resetting to empty array.');
    return [];
  } catch (error) {
    console.error('[TaskFlow] Error loading tasks from localStorage:', error);
    showToast('Failed to load saved tasks from local storage.', 'error');
    return [];
  }
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks));
  } catch (error) {
    console.error('[TaskFlow] Error saving tasks to localStorage:', error);
    showToast('Storage quota exceeded or storage unavailable!', 'error');
  }
}

function generateId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'task_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 8);
}

function formatTaskDate(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  }).format(date);
}

function displayCurrentDate() {
  const now = new Date();
  const options = { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' };
  elements.currentDate.textContent = now.toLocaleDateString('en-US', options);
}

function showToast(message, type = 'success', duration = 3000) {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', 'alert');

  let iconSvg = '';
  if (type === 'success') {
    iconSvg = `
      <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
        <polyline points="22 4 12 14.01 9 11.01"/>
      </svg>
    `;
  } else if (type === 'error') {
    iconSvg = `
      <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="15" y1="9" x2="9" y2="15"/>
        <line x1="9" y1="9" x2="15" y2="15"/>
      </svg>
    `;
  } else {
    iconSvg = `
      <svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="16" x2="12" y2="12"/>
        <line x1="12" y1="8" x2="12.01" y2="8"/>
      </svg>
    `;
  }

  toast.innerHTML = `
    ${iconSvg}
    <span class="toast-message"></span>
  `;

  toast.querySelector('.toast-message').textContent = message;

  elements.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-exit');
    toast.addEventListener('transitionend', () => {
      toast.remove();
    }, { once: true });
  }, duration);
}

function openConfirmModal({ title, message, confirmText = 'Confirm', onConfirm }) {
  elements.modalTitle.textContent = title;
  elements.modalMessage.textContent = message;
  elements.modalConfirmBtn.textContent = confirmText;
  pendingModalAction = onConfirm;

  elements.confirmModal.classList.remove('hidden');
  elements.modalConfirmBtn.focus();
}

function closeConfirmModal() {
  elements.confirmModal.classList.add('hidden');
  pendingModalAction = null;
}

function validateInput(text) {
  const trimmed = text.trim();
  if (trimmed.length === 0) {
    elements.taskInput.classList.add('input-error');
    elements.formError.textContent = 'Please enter a task description before submitting.';
    elements.formError.classList.remove('hidden');
    elements.taskInput.focus();
    return null;
  }

  clearInputError();
  return trimmed;
}

function clearInputError() {
  elements.taskInput.classList.remove('input-error');
  elements.formError.textContent = '';
  elements.formError.classList.add('hidden');
}

function updateStatistics() {
  const total = state.tasks.length;

  const activeTasks = state.tasks.filter(task => !task.completed);
  const completedTasks = state.tasks.filter(task => task.completed);

  const activeCount = activeTasks.length;
  const completedCount = completedTasks.length;

  const percentage = total === 0 ? 0 : Math.round((completedCount / total) * 100);

  elements.statTotal.textContent = total;
  elements.statActive.textContent = activeCount;
  elements.statCompleted.textContent = completedCount;
  elements.statPercent.textContent = `${percentage}%`;

  elements.progressBarFill.style.width = `${percentage}%`;
  elements.progressBarContainer.setAttribute('aria-valuenow', percentage);

  elements.filterAllCount.textContent = total;
  elements.filterActiveCount.textContent = activeCount;
  elements.filterCompletedCount.textContent = completedCount;

  elements.remainingCount.textContent = `${activeCount} task${activeCount === 1 ? '' : 's'} left`;

  elements.clearCompletedBtn.disabled = completedCount === 0;
}

function getFilteredTasks() {
  switch (state.currentFilter) {
    case 'active':
      return state.tasks.filter(task => !task.completed);
    case 'completed':
      return state.tasks.filter(task => task.completed);
    case 'all':
    default:
      return state.tasks;
  }
}

function renderEmptyState() {
  let title = 'No tasks found';
  let message = 'Your task list is empty. Add a new task above!';
  let iconSvg = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14 2 14 8 20 8"/>
      <line x1="16" y1="13" x2="8" y2="13"/>
      <line x1="16" y1="17" x2="8" y2="17"/>
      <polyline points="10 9 9 9 8 9"/>
    </svg>
  `;

  if (state.tasks.length === 0) {
    title = 'No tasks yet';
    message = 'You have no scheduled tasks. Start your day by adding one above!';
  } else if (state.currentFilter === 'active') {
    title = 'All caught up!';
    message = 'No active tasks remaining. Great job tackling your list!';
    iconSvg = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
        <polyline points="22 4 12 14.01 9 11.01"/>
      </svg>
    `;
  } else if (state.currentFilter === 'completed') {
    title = 'No completed tasks';
    message = 'Completed tasks will appear here once you check them off.';
    iconSvg = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="8" x2="12" y2="12"/>
        <line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
    `;
  }

  elements.emptyState.innerHTML = `
    <div class="empty-state-icon">
      ${iconSvg}
    </div>
    <h3 class="empty-state-title">${title}</h3>
    <p class="empty-state-text">${message}</p>
  `;

  elements.emptyState.classList.remove('hidden');
}

function createTaskElement(task) {
  const li = document.createElement('li');
  li.className = `task-item ${task.completed ? 'completed' : ''} ${state.editingTaskId === task.id ? 'is-editing' : ''}`;
  li.dataset.id = task.id;

  const contentWrapper = document.createElement('div');
  contentWrapper.className = 'task-content';

  const checkBtn = document.createElement('button');
  checkBtn.type = 'button';
  checkBtn.className = 'task-checkbox-btn';
  checkBtn.setAttribute('data-action', 'toggle');
  checkBtn.setAttribute('aria-label', task.completed ? 'Mark task as active' : 'Mark task as completed');
  checkBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  `;

  const details = document.createElement('div');
  details.className = 'task-details';

  const textSpan = document.createElement('span');
  textSpan.className = 'task-text';

  textSpan.textContent = task.text;

  const metaSpan = document.createElement('span');
  metaSpan.className = 'task-meta';
  metaSpan.textContent = formatTaskDate(task.createdAt);

  details.appendChild(textSpan);
  details.appendChild(metaSpan);

  contentWrapper.appendChild(checkBtn);
  contentWrapper.appendChild(details);

  const actionsWrapper = document.createElement('div');
  actionsWrapper.className = 'task-actions';

  const editBtn = document.createElement('button');
  editBtn.type = 'button';
  editBtn.className = 'action-btn edit-btn';
  editBtn.setAttribute('data-action', 'edit');
  editBtn.setAttribute('aria-label', 'Edit task');
  editBtn.title = 'Edit task';
  editBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
    </svg>
  `;

  const deleteBtn = document.createElement('button');
  deleteBtn.type = 'button';
  deleteBtn.className = 'action-btn delete-btn';
  deleteBtn.setAttribute('data-action', 'delete');
  deleteBtn.setAttribute('aria-label', 'Delete task');
  deleteBtn.title = 'Delete task';
  deleteBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="3 6 5 6 21 6"/>
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      <line x1="10" y1="11" x2="10" y2="17"/>
      <line x1="14" y1="11" x2="14" y2="17"/>
    </svg>
  `;

  actionsWrapper.appendChild(editBtn);
  actionsWrapper.appendChild(deleteBtn);

  li.appendChild(contentWrapper);
  li.appendChild(actionsWrapper);

  return li;
}

function renderTasks() {
  const filteredTasks = getFilteredTasks();

  elements.taskList.innerHTML = '';

  if (filteredTasks.length === 0) {
    renderEmptyState();
  } else {
    elements.emptyState.classList.add('hidden');
    const fragment = document.createDocumentFragment();

    filteredTasks.forEach(task => {
      const taskElement = createTaskElement(task);
      fragment.appendChild(taskElement);
    });

    elements.taskList.appendChild(fragment);
  }

  updateStatistics();
}

function addTask(text) {
  const newTask = {
    id: generateId(),
    text: text,
    completed: false,
    createdAt: Date.now()
  };

  state.tasks.unshift(newTask);

  saveTasks();
  renderTasks();

  elements.taskInput.value = '';
  elements.charCount.textContent = '0/150';
  elements.taskInput.focus();

  showToast('Task added successfully!', 'success');
}

function editTask(taskId) {

  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  state.editingTaskId = taskId;

  elements.taskInput.value = task.text;
  elements.charCount.textContent = `${task.text.length}/150`;

  elements.submitBtnText.textContent = 'Update Task';
  elements.submitBtn.classList.add('btn-editing');

  elements.cancelBtn.classList.remove('hidden');

  clearInputError();
  elements.taskInput.focus();

  renderTasks();

  elements.taskForm.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function saveEditedTask(taskId, newText) {
  const index = state.tasks.findIndex(t => t.id === taskId);
  if (index !== -1) {
    state.tasks[index].text = newText;
    saveTasks();
    showToast('Task updated successfully!', 'success');
  }
  cancelEdit();
}

function cancelEdit() {
  state.editingTaskId = null;
  elements.taskInput.value = '';
  elements.charCount.textContent = '0/150';
  elements.submitBtnText.textContent = 'Add Task';
  elements.submitBtn.classList.remove('btn-editing');
  elements.cancelBtn.classList.add('hidden');
  clearInputError();
  renderTasks();
}

function toggleTask(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  task.completed = !task.completed;
  saveTasks();
  renderTasks();

  const statusMessage = task.completed ? 'Task marked as completed!' : 'Task reactivated!';
  showToast(statusMessage, 'info');
}

function deleteTask(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  const taskSnippet = task ? `"${task.text.substring(0, 25)}${task.text.length > 25 ? '...' : ''}"` : 'this task';

  openConfirmModal({
    title: 'Delete Task',
    message: `Are you sure you want to delete ${taskSnippet}? This action cannot be undone.`,
    confirmText: 'Delete',
    onConfirm: () => {

      if (state.editingTaskId === taskId) {
        cancelEdit();
      }

      state.tasks = state.tasks.filter(t => t.id !== taskId);
      saveTasks();
      renderTasks();
      showToast('Task deleted successfully.', 'info');
    }
  });
}

function filterTasks(filterType) {
  state.currentFilter = filterType;

  elements.filterButtons.forEach(btn => {
    const isTarget = btn.dataset.filter === filterType;
    btn.classList.toggle('active', isTarget);
    btn.setAttribute('aria-selected', isTarget ? 'true' : 'false');
  });

  renderTasks();
}

function clearCompletedTasks() {
  const completedCount = state.tasks.filter(t => t.completed).length;
  if (completedCount === 0) return;

  openConfirmModal({
    title: 'Clear Completed Tasks',
    message: `Are you sure you want to permanently clear ${completedCount} completed task${completedCount === 1 ? '' : 's'}?`,
    confirmText: 'Clear All',
    onConfirm: () => {

      const editingTask = state.tasks.find(t => t.id === state.editingTaskId);
      if (editingTask && editingTask.completed) {
        cancelEdit();
      }

      state.tasks = state.tasks.filter(t => !t.completed);
      saveTasks();
      renderTasks();
      showToast(`Cleared ${completedCount} completed task${completedCount === 1 ? '' : 's'}!`, 'info');
    }
  });
}

function setupEventListeners() {

  elements.taskForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const validatedText = validateInput(elements.taskInput.value);
    if (!validatedText) return;

    if (state.editingTaskId) {
      saveEditedTask(state.editingTaskId, validatedText);
    } else {
      addTask(validatedText);
    }
  });

  elements.cancelBtn.addEventListener('click', cancelEdit);

  elements.taskInput.addEventListener('input', () => {
    const currentLength = elements.taskInput.value.length;
    elements.charCount.textContent = `${currentLength}/150`;
    if (elements.taskInput.classList.contains('input-error')) {
      clearInputError();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!elements.confirmModal.classList.contains('hidden')) {
        closeConfirmModal();
      } else if (state.editingTaskId) {
        cancelEdit();
      }
    }
  });

  elements.taskList.addEventListener('click', (e) => {

    const actionBtn = e.target.closest('[data-action]');
    if (!actionBtn) return;

    const taskItem = actionBtn.closest('.task-item');
    if (!taskItem) return;

    const taskId = taskItem.dataset.id;
    const action = actionBtn.dataset.action;

    switch (action) {
      case 'toggle':
        toggleTask(taskId);
        break;
      case 'edit':
        editTask(taskId);
        break;
      case 'delete':
        deleteTask(taskId);
        break;
      default:
        break;
    }
  });

  elements.filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterTasks(filter);
    });
  });

  elements.clearCompletedBtn.addEventListener('click', clearCompletedTasks);

  elements.modalConfirmBtn.addEventListener('click', () => {
    if (typeof pendingModalAction === 'function') {
      pendingModalAction();
    }
    closeConfirmModal();
  });

  elements.modalCancelBtn.addEventListener('click', closeConfirmModal);

  elements.confirmModal.addEventListener('click', (e) => {
    if (e.target === elements.confirmModal) {
      closeConfirmModal();
    }
  });
}

function init() {
  displayCurrentDate();
  state.tasks = loadTasks();
  setupEventListeners();
  renderTasks();
  console.log('[TaskFlow] Application initialized successfully with', state.tasks.length, 'tasks.');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
